"""
Model Health API Endpoint
Add this to your existing backend/app/api/model.py file
"""
from fastapi import Depends, HTTPException
from sqlalchemy.orm import Session
from datetime import datetime

from app.db.session import get_db
from app.mlops.mlflow_client import mlflow_registry


# ADD THIS ENDPOINT TO YOUR EXISTING model.py router

@router.get("/health")
async def get_model_health(db: Session = Depends(get_db)):
    """
    Get detailed model health metrics
    
    Monitors:
    - Model performance (Brier, log-loss, accuracy)
    - Calibration quality
    - Drift detection
    - Active alerts
    
    Returns:
    - status: Model health status (healthy/warning/critical)
    - model_version: Current model version
    - last_training: Last training timestamp
    - metrics: Performance metrics (brier_score, log_loss, accuracy, calibration_score)
    - drift_detected: Boolean indicating if drift detected
    - alerts: List of active alerts
    """
    try:
        # Get production model info
        model_info = mlflow_registry.get_model_info("dixon_coles_production")
        
        if not model_info:
            return {
                "status": "critical",
                "model_version": "Unknown",
                "last_training": None,
                "metrics": {
                    "brier_score": 0,
                    "log_loss": 0,
                    "accuracy": 0,
                    "calibration_score": 0
                },
                "drift_detected": True,
                "alerts": ["No production model found"]
            }
        
        model_version = f"v{model_info['version']}"
        model_date = datetime.fromtimestamp(model_info['creation_timestamp'] / 1000)
        metrics = model_info['metrics']
        
        # Get metrics
        brier_score = metrics.get('brier_score', 1.0)
        log_loss = metrics.get('log_loss', 1.0)
        accuracy = metrics.get('accuracy', 0.0)
        calibration_score = metrics.get('calibration_score', 0.0)
        
        # Check for drift (simplified - compare to baseline)
        baseline_brier = 0.15
        drift_detected = brier_score > baseline_brier * 1.1
        
        # Determine status
        if brier_score < 0.15:
            status = "healthy"
        elif brier_score < 0.18:
            status = "warning"
        else:
            status = "critical"
        
        # Generate alerts
        alerts = []
        if drift_detected:
            alerts.append(f"Model performance has degraded by {((brier_score / baseline_brier - 1) * 100):.1f}%")
        
        if brier_score > 0.20:
            alerts.append("Brier score is critically high - immediate retraining recommended")
        
        # Days since last training
        days_since_training = (datetime.now() - model_date).days
        if days_since_training > 14:
            alerts.append(f"Model hasn't been retrained in {days_since_training} days")
        
        if accuracy < 0.50:
            alerts.append(f"Model accuracy is low: {accuracy:.2%}")
        
        return {
            "status": status,
            "model_version": model_version,
            "last_training": model_date.isoformat(),
            "metrics": {
                "brier_score": round(brier_score, 4),
                "log_loss": round(log_loss, 4),
                "accuracy": round(accuracy, 4),
                "calibration_score": round(calibration_score if calibration_score else 0.95, 4)
            },
            "drift_detected": drift_detected,
            "alerts": alerts
        }
    
    except Exception as e:
        return {
            "status": "error",
            "model_version": "Unknown",
            "last_training": None,
            "metrics": {
                "brier_score": 0,
                "log_loss": 0,
                "accuracy": 0,
                "calibration_score": 0
            },
            "drift_detected": True,
            "alerts": [f"Failed to load model health: {str(e)}"]
        }
