"""
MLflow Model Registry Client
Handles model lifecycle management and experiment tracking
"""
import mlflow
from mlflow.tracking import MlflowClient
from pathlib import Path
import os
from typing import Dict, Optional, List
from datetime import datetime

# Configure MLflow
MLFLOW_TRACKING_URI = os.getenv("MLFLOW_TRACKING_URI", "http://localhost:5000")
MLFLOW_ARTIFACT_ROOT = os.getenv("MLFLOW_ARTIFACT_ROOT", "./mlflow/artifacts")

mlflow.set_tracking_uri(MLFLOW_TRACKING_URI)


class MLflowModelRegistry:
    """Manages model lifecycle with MLflow"""
    
    def __init__(self):
        self.client = MlflowClient()
        
    def create_experiment(self, name: str, description: str = "") -> str:
        """Create MLflow experiment"""
        try:
            experiment_id = self.client.create_experiment(
                name=name,
                artifact_location=f"{MLFLOW_ARTIFACT_ROOT}/{name}",
                tags={"description": description}
            )
            return experiment_id
        except Exception:
            # Experiment exists
            experiment = self.client.get_experiment_by_name(name)
            return experiment.experiment_id
    
    def log_training_run(
        self,
        experiment_name: str,
        model,
        params: Dict,
        metrics: Dict,
        artifacts: Dict = None
    ) -> str:
        """
        Log a training run to MLflow
        
        Args:
            experiment_name: Name of experiment
            model: Trained model object
            params: Hyperparameters
            metrics: Validation metrics
            artifacts: Additional artifacts to log
            
        Returns:
            run_id: MLflow run ID
        """
        experiment_id = self.create_experiment(experiment_name)
        
        with mlflow.start_run(experiment_id=experiment_id):
            # Log parameters
            mlflow.log_params(params)
            
            # Log metrics
            mlflow.log_metrics(metrics)
            
            # Log model
            mlflow.sklearn.log_model(
                model,
                "model",
                registered_model_name=f"dixon_coles_{experiment_name}"
            )
            
            # Log additional artifacts
            if artifacts:
                for name, artifact in artifacts.items():
                    mlflow.log_artifact(artifact, name)
            
            run_id = mlflow.active_run().info.run_id
            return run_id
    
    def load_production_model(self, model_name: str = "dixon_coles_production"):
        """Load current production model"""
        try:
            model = mlflow.pyfunc.load_model(f"models:/{model_name}/Production")
            return model
        except Exception:
            # Fallback to latest version
            latest_versions = self.client.get_latest_versions(model_name, stages=["None"])
            if latest_versions:
                model = mlflow.pyfunc.load_model(
                    f"models:/{model_name}/{latest_versions[0].version}"
                )
                return model
            raise ValueError(f"No model found: {model_name}")
    
    def get_model_info(self, model_name: str = "dixon_coles_production") -> Optional[Dict]:
        """Get information about current production model"""
        try:
            versions = self.client.get_latest_versions(model_name, stages=["Production"])
            if not versions:
                # Try latest version if no production
                versions = self.client.get_latest_versions(model_name, stages=["None"])
            
            if versions:
                model_info = versions[0]
                run = self.client.get_run(model_info.run_id)
                
                return {
                    "version": model_info.version,
                    "stage": model_info.current_stage,
                    "creation_timestamp": model_info.creation_timestamp,
                    "run_id": model_info.run_id,
                    "metrics": run.data.metrics,
                    "params": run.data.params
                }
            return None
        except Exception as e:
            print(f"Error getting model info: {e}")
            return None
    
    def promote_to_production(self, model_name: str, version: str):
        """Promote model version to production"""
        # Archive current production
        for mv in self.client.get_latest_versions(model_name, stages=["Production"]):
            self.client.transition_model_version_stage(
                name=model_name,
                version=mv.version,
                stage="Archived"
            )
        
        # Promote new version
        self.client.transition_model_version_stage(
            name=model_name,
            version=version,
            stage="Production"
        )
    
    def get_experiment_history(self, experiment_name: str, max_results: int = 10) -> List[Dict]:
        """Get experiment run history"""
        experiment = self.client.get_experiment_by_name(experiment_name)
        if not experiment:
            return []
        
        runs = self.client.search_runs(
            experiment_ids=[experiment.experiment_id],
            max_results=max_results,
            order_by=["start_time DESC"]
        )
        
        return [
            {
                "run_id": run.info.run_id,
                "start_time": datetime.fromtimestamp(run.info.start_time / 1000),
                "end_time": datetime.fromtimestamp(run.info.end_time / 1000) if run.info.end_time else None,
                "status": run.info.status,
                "metrics": run.data.metrics,
                "params": run.data.params
            }
            for run in runs
        ]
    
    def compare_models(self, model_name: str, version1: str, version2: str) -> Dict:
        """Compare two model versions"""
        try:
            mv1 = self.client.get_model_version(model_name, version1)
            mv2 = self.client.get_model_version(model_name, version2)
            
            run1 = self.client.get_run(mv1.run_id)
            run2 = self.client.get_run(mv2.run_id)
            
            return {
                "version_1": {
                    "version": version1,
                    "metrics": run1.data.metrics,
                    "params": run1.data.params
                },
                "version_2": {
                    "version": version2,
                    "metrics": run2.data.metrics,
                    "params": run2.data.params
                },
                "comparison": {
                    metric: {
                        "v1": run1.data.metrics.get(metric, 0),
                        "v2": run2.data.metrics.get(metric, 0),
                        "diff": run2.data.metrics.get(metric, 0) - run1.data.metrics.get(metric, 0)
                    }
                    for metric in set(list(run1.data.metrics.keys()) + list(run2.data.metrics.keys()))
                }
            }
        except Exception as e:
            return {"error": str(e)}


# Singleton instance
mlflow_registry = MLflowModelRegistry()
