"""
Simple Redis-based Feature Store
Fast feature serving for predictions
"""
import redis
import json
from typing import Dict, List, Optional
from datetime import datetime, timedelta


class SimpleFeatureStore:
    """
    Redis-based feature store for fast feature serving
    
    Features stored as JSON in Redis with TTL
    """
    
    def __init__(self, redis_client: redis.Redis):
        self.redis = redis_client
        self.prefix = "feature_store:"
        
    def _make_key(self, entity: str, entity_id: int, feature_group: str) -> str:
        """Generate Redis key for feature"""
        return f"{self.prefix}{entity}:{entity_id}:{feature_group}"
    
    def store_team_features(
        self,
        team_id: int,
        features: Dict[str, float],
        ttl_days: int = 7
    ):
        """
        Store team features
        
        Args:
            team_id: Team ID
            features: Dictionary of features
            ttl_days: Time-to-live in days
        """
        key = self._make_key("team", team_id, "stats")
        
        feature_data = {
            "team_id": team_id,
            "features": features,
            "updated_at": datetime.now().isoformat(),
            "version": "1.0"
        }
        
        self.redis.setex(
            key,
            timedelta(days=ttl_days),
            json.dumps(feature_data)
        )
    
    def get_team_features(self, team_id: int) -> Optional[Dict]:
        """Get team features from cache"""
        key = self._make_key("team", team_id, "stats")
        data = self.redis.get(key)
        
        if data:
            return json.loads(data)
        return None
    
    def store_match_features(
        self,
        home_team_id: int,
        away_team_id: int,
        match_date: str,
        features: Dict[str, float],
        ttl_hours: int = 24
    ):
        """Store match-level features"""
        key = f"{self.prefix}match:{home_team_id}:{away_team_id}:{match_date}"
        
        feature_data = {
            "home_team_id": home_team_id,
            "away_team_id": away_team_id,
            "match_date": match_date,
            "features": features,
            "updated_at": datetime.now().isoformat()
        }
        
        self.redis.setex(
            key,
            timedelta(hours=ttl_hours),
            json.dumps(feature_data)
        )
    
    def get_match_features(
        self,
        home_team_id: int,
        away_team_id: int,
        match_date: str
    ) -> Optional[Dict]:
        """Get match features from cache"""
        key = f"{self.prefix}match:{home_team_id}:{away_team_id}:{match_date}"
        data = self.redis.get(key)
        
        if data:
            return json.loads(data)
        return None
    
    def bulk_store_features(self, features_list: List[Dict]):
        """Bulk store multiple features"""
        pipe = self.redis.pipeline()
        
        for feature_data in features_list:
            entity_type = feature_data["entity_type"]
            entity_id = feature_data["entity_id"]
            features = feature_data["features"]
            ttl = feature_data.get("ttl_days", 7)
            
            if entity_type == "team":
                key = self._make_key("team", entity_id, "stats")
                pipe.setex(
                    key,
                    timedelta(days=ttl),
                    json.dumps({
                        "team_id": entity_id,
                        "features": features,
                        "updated_at": datetime.now().isoformat()
                    })
                )
        
        pipe.execute()
    
    def invalidate_team_features(self, team_id: int):
        """Invalidate team features (e.g., after model retraining)"""
        key = self._make_key("team", team_id, "stats")
        self.redis.delete(key)
    
    def invalidate_all(self):
        """Invalidate all features (after retraining)"""
        pattern = f"{self.prefix}*"
        keys = self.redis.keys(pattern)
        if keys:
            self.redis.delete(*keys)
    
    def get_feature_stats(self) -> Dict:
        """Get statistics about feature store"""
        pattern = f"{self.prefix}*"
        keys = self.redis.keys(pattern)
        
        team_keys = [k for k in keys if b"team:" in k]
        match_keys = [k for k in keys if b"match:" in k]
        
        total_memory = 0
        for key in keys:
            try:
                total_memory += self.redis.memory_usage(key) or 0
            except:
                pass
        
        return {
            "total_features": len(keys),
            "team_features": len(team_keys),
            "match_features": len(match_keys),
            "memory_usage_mb": round(total_memory / 1024 / 1024, 2)
        }
