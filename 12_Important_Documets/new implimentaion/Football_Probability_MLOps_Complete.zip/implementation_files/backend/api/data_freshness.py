"""
Data Freshness API Endpoint
Add this to your existing backend/app/api/data.py file
"""
from fastapi import Depends
from sqlalchemy.orm import Session
from sqlalchemy import func
from datetime import datetime, timedelta

from app.db.session import get_db
from app.db.models import Match, League


# ADD THIS ENDPOINT TO YOUR EXISTING data.py router

@router.get("/freshness")
async def get_data_freshness(db: Session = Depends(get_db)):
    """
    Get data freshness metrics
    
    Returns information about data currency and completeness
    
    Returns:
    - last_update: Date of most recent match in database
    - matches_count: Total number of matches
    - leagues_active: Number of leagues with recent matches
    - stale_data: Boolean indicating if data is stale (>7 days old)
    """
    try:
        # Get last match date
        last_match = db.query(func.max(Match.match_date)).scalar()
        
        # Get total matches
        total_matches = db.query(func.count(Match.id)).scalar() or 0
        
        # Get active leagues (with matches in last 90 days)
        cutoff_date = datetime.now() - timedelta(days=90)
        active_leagues = db.query(func.count(func.distinct(Match.league_id))).filter(
            Match.match_date >= cutoff_date.date()
        ).scalar() or 0
        
        # Check if data is stale (no matches in last 7 days)
        stale_cutoff = datetime.now() - timedelta(days=7)
        stale_data = last_match < stale_cutoff.date() if last_match else True
        
        return {
            "last_update": last_match.isoformat() if last_match else None,
            "matches_count": total_matches,
            "leagues_active": active_leagues,
            "stale_data": stale_data
        }
    
    except Exception as e:
        return {
            "last_update": None,
            "matches_count": 0,
            "leagues_active": 0,
            "stale_data": True,
            "error": str(e)
        }
