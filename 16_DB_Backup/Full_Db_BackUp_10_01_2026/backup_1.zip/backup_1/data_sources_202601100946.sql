INSERT INTO public.data_sources (id,"name",source_type,status,last_sync_at,record_count,last_error,config,created_at,updated_at) VALUES
	 (3,'football-data.co.uk','csv','fresh','2026-01-09 13:23:33.684054+03',140,NULL,NULL,'2026-01-08 17:51:50.347262+03','2026-01-09 13:23:33.683434+03'),
	 (4,'football-data.org','api','running',NULL,0,NULL,NULL,'2026-01-08 18:53:47.708975+03','2026-01-08 18:53:47.708975+03'),
	 (5,'OpenFootball','csv','fresh','2026-01-09 13:35:24.247569+03',154,NULL,NULL,'2026-01-08 19:05:13.314557+03','2026-01-09 13:35:24.246525+03');
