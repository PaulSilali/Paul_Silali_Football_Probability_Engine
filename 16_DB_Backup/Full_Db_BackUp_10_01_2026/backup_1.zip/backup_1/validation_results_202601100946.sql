INSERT INTO public.validation_results (id,jackpot_id,set_type,model_id,total_matches,correct_predictions,accuracy,brier_score,log_loss,home_correct,home_total,draw_correct,draw_total,away_correct,away_total,exported_to_training,exported_at,created_at) VALUES
	 (1,13,'J'::public.prediction_set,13,10,2,20.0,0.7333743690000001,1.2004331562726134,1,3,1,2,0,5,true,'2026-01-09 11:52:00.728104+03','2026-01-09 11:51:58.59598+03'),
	 (2,13,'J'::public.prediction_set,13,10,2,20.0,0.7333743690000001,1.2004331562726134,1,3,1,2,0,5,true,'2026-01-09 12:01:53.741612+03','2026-01-09 12:01:51.453961+03'),
	 (3,13,'J'::public.prediction_set,13,10,2,20.0,0.7333743690000001,1.2004331562726134,1,3,1,2,0,5,true,'2026-01-09 12:07:00.1828+03','2026-01-09 12:06:57.690257+03');
